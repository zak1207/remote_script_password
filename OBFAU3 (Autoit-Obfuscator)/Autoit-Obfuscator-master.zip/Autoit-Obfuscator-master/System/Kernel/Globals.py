#!/usr/bin/env python
# -*- coding: utf-8 -*-

__import__("sys").path.append('./System')

global max_size_len_autoit 
max_size_len_autoit = 4095
global defined_new_functions
defined_new_functions = []
global arity_new_functions
arity_new_functions   = []
global defined_new_variables
defined_new_variables = []
global directories_files
directories_files     = {}
global string_replace_function
string_replace_function = None
global string_reverse_function
string_reverse_function = None
global string_flip_two_function
string_flip_two_function = None
global string_rotate_function
string_rotate_function = None
global string_shuffle_function
string_shuffle_function = None
